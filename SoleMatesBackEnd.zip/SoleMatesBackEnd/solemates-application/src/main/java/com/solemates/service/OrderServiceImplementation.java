package com.solemates.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.solemates.exception.OrderException;
import com.solemates.model.Address;
import com.solemates.model.Cart;
import com.solemates.model.CartItem;
import com.solemates.model.Order;
import com.solemates.model.OrderItem;
import com.solemates.model.PaymentDetails;
import com.solemates.model.User;
import com.solemates.repository.OrderItemRepository;
import com.solemates.repository.OrderRepository;
import com.solemates.repository.UserRepository;

@Service
public class OrderServiceImplementation implements OrderService {
    
    @Autowired
    private OrderRepository orderRepository; 
    @Autowired
    private CartService cartService;
    @Autowired
    private AddressRepository addressRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private OrderItemRepository orderItemRepository;

//    public OrderServiceImplementation(OrderRepository orderRepository, CartService cartService,
//                                      AddressRepository addressRepository, UserRepository userRepository,
//                                      OrderItemRepository orderItemRepository) {
//        this.orderRepository = orderRepository;
//        this.cartService = cartService;
//        this.addressRepository = addressRepository;
//        this.userRepository = userRepository;
//        this.orderItemRepository = orderItemRepository;
//    }
    
    
    
    @Override
    public Order createOrder(User user, Address shippingAddress) {
        // Validate input
        if (user == null || shippingAddress == null) {
            throw new IllegalArgumentException("User or shipping address cannot be null");
        }
        // Further validations based on your check constraints

        shippingAddress.setUser(user);
        Address address = addressRepository.save(shippingAddress);
        user.getAddresses().add(address);
        userRepository.save(user);

        Cart cart = cartService.findUserCart(user.getId());
        if (cart == null || cart.getCartItems().isEmpty()) {
            throw new IllegalArgumentException("Cart is empty or not found");
        }
        
        List<OrderItem> orderItems = new ArrayList<>();

        for (CartItem item : cart.getCartItems()) {
            OrderItem orderItem = new OrderItem();
            orderItem.setPrice(item.getPrice());
            orderItem.setProduct(item.getProduct());
            orderItem.setQuantity(item.getQuantity());
            orderItem.setSize(item.getSize());
            orderItem.setUserId(item.getUserId());
            orderItem.setDiscountedPrice(item.getDiscountedPrice());

            OrderItem createdOrderItem = orderItemRepository.save(orderItem);
            orderItems.add(createdOrderItem);
        }

        Order createdOrder = new Order();
        createdOrder.setUser(user);
        createdOrder.setOrderItems(orderItems);
        createdOrder.setTotalPrice(cart.getTotalPrice());
        createdOrder.setTotalDiscountedPrice(cart.getTotalDiscountedPrice());
        createdOrder.setDiscount(cart.getDiscount());
        createdOrder.setTotalItem(cart.getTotalItem());
        createdOrder.setShippingAddress(address);
        createdOrder.setOrderDate(LocalDateTime.now());
        createdOrder.setOrderStatus("PENDING");

        PaymentDetails paymentDetails = createdOrder.getPaymentDetails();
        if (paymentDetails == null) {
            paymentDetails = new PaymentDetails();
            createdOrder.setPaymentDetails(paymentDetails);
        }
        paymentDetails.setStatus("PENDING");
        createdOrder.setCreatedAt(LocalDateTime.now());

        // Validate total price and other fields
        if (createdOrder.getTotalPrice() < 0 || createdOrder.getTotalDiscountedPrice() < 0) {
            throw new IllegalArgumentException("Total price or discounted price cannot be negative");
        }

        Order savedOrder = orderRepository.save(createdOrder);

        for (OrderItem item : orderItems) {
            item.setOrder(savedOrder);
            orderItemRepository.save(item);
        }

        return savedOrder;
    }

    
    
    
    
    
    
    
    
    

//    @Override
//    public Order createOrder(User user, Address shippingAddress) {
//        shippingAddress.setUser(user);
//        Address address = addressRepository.save(shippingAddress);
//        user.getAddresses().add(address);
//        userRepository.save(user);
//
//        Cart cart = cartService.findUserCart(user.getId());
//        List<OrderItem> orderItems = new ArrayList<>();
//
//        for (CartItem item : cart.getCartItems()) {
//            OrderItem orderItem = new OrderItem();
//            orderItem.setPrice(item.getPrice());
//            orderItem.setProduct(item.getProduct());
//            orderItem.setQuantity(item.getQuantity());
//            orderItem.setSize(item.getSize());
//            orderItem.setUserId(item.getUserId());
//            orderItem.setDiscountedPrice(item.getDiscountedPrice());
//
//            OrderItem createdOrderItem = orderItemRepository.save(orderItem);
//            orderItems.add(createdOrderItem);
//        }
//
//        Order createdOrder = new Order();
//        createdOrder.setUser(user);
//        createdOrder.setOrderItems(orderItems);
//        createdOrder.setTotalPrice(cart.getTotalPrice());
//        createdOrder.setTotalDiscountedPrice(cart.getTotalDiscountedPrice());
//        createdOrder.setDiscount(cart.getDiscount());
//        createdOrder.setTotalItem(cart.getTotalItem());
//        createdOrder.setShippingAddress(address);
//        createdOrder.setOrderDate(LocalDateTime.now());
//        createdOrder.setOrderStatus("PENDING"); // Changed to String
//
//        PaymentDetails paymentDetails = createdOrder.getPaymentDetails();
//        if (paymentDetails == null) {
//            paymentDetails = new PaymentDetails();
//            createdOrder.setPaymentDetails(paymentDetails);
//        }
//        paymentDetails.setStatus("PENDING"); // Changed to String
//        createdOrder.setCreatedAt(LocalDateTime.now());
//
//        Order savedOrder = orderRepository.save(createdOrder);
//
//        for (OrderItem item : orderItems) {
//            item.setOrder(savedOrder);
//            orderItemRepository.save(item);
//        }
//
//        return savedOrder;
//    }

    @Override
    public Order findOrderById(Long orderId) throws OrderException {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderException("Order does not exist with id " + orderId));
    }

    @Override
    public List<Order> usersOrderHistory(Long userId) {
        return orderRepository.getUsersOrders(userId);
    }

    @Override
    public Order placedOrder(Long orderId) throws OrderException {
        Order order = findOrderById(orderId);
        order.setOrderStatus("PLACED"); // Changed to String
        order.getPaymentDetails().setStatus("COMPLETED"); // Changed to String
        return orderRepository.save(order);
    }

    @Override
    public Order confirmedOrder(Long orderId) throws OrderException {
        Order order = findOrderById(orderId);
        order.setOrderStatus("CONFIRMED"); // Changed to String
        return orderRepository.save(order);
    }

    @Override
    public Order shippedOrder(Long orderId) throws OrderException {
        Order order = findOrderById(orderId);
        order.setOrderStatus("SHIPPED"); // Changed to String
        return orderRepository.save(order);
    }

    @Override
    public Order deliveredOrder(Long orderId) throws OrderException {
        Order order = findOrderById(orderId);
        order.setOrderStatus("DELIVERED"); // Changed to String
        return orderRepository.save(order);
    }

    @Override
    public Order canceledOrder(Long orderId) throws OrderException {
        Order order = findOrderById(orderId);
        order.setOrderStatus("CANCELLED"); // Changed to String
        return orderRepository.save(order);
    }

    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    @Override
    public void deleteOrder(Long orderId) throws OrderException {
        Order order = findOrderById(orderId);
        orderRepository.deleteById(orderId);
    }
}
