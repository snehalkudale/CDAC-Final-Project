package com.solemates.service;

import com.solemates.model.OrderItem;

public interface OrderItemService {
	
	public OrderItem createOrderItem(OrderItem orderItem);


}
