package com.solemates.service;

import java.util.List;

import com.solemates.exception.ProductException;
import com.solemates.model.Review;
import com.solemates.model.User;
import com.solemates.request.ReviewRequest;

public interface ReviewService {
	
    public Review createReview(ReviewRequest req,User user) throws ProductException;
	
	public List<Review> getAllReview(Long productId);

}
