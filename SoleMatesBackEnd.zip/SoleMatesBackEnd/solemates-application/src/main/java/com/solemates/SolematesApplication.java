package com.solemates;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SolematesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SolematesApplication.class, args);
	}

}
