package com.solemates.service;

import com.solemates.exception.UserException;
import com.solemates.model.User;

public interface UserService {
	
	public User findUserById(Long userId) throws UserException;
	
	public User findUserProfileByJwt(String jwt) throws UserException;

}
