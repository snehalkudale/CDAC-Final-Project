package com.solemates.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.solemates.model.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {

}
