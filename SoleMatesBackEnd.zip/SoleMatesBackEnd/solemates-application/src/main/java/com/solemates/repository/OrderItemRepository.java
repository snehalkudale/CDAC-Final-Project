package com.solemates.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.solemates.model.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {

}
