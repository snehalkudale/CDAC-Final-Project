package com.solemates.service;

import java.util.List;

import com.solemates.exception.ProductException;
import com.solemates.model.Rating;
import com.solemates.model.User;
import com.solemates.request.RatingRequest;

public interface RatingService {
	
    public Rating createRating(RatingRequest req,User user) throws ProductException;
	
	public List<Rating> getProductsRating(Long productId);

}
