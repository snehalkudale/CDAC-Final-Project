package com.solemates.config;

public class JwtConstant {
	
	public static final String SECRET_KEY = "dbcsvhnbkhvbsddhcbhfbdcvfhcvbfcvbfchvb";
	public static final String JWT_HEADER = "Authorization";

}
